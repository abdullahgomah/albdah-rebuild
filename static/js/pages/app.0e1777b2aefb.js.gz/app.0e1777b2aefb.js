var swiper = new Swiper(".mySwiper", {
    freeMode: true,
    slidesPerView: 1,
    spaceBetween: 1, 
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });


// Make navbar responsive 

